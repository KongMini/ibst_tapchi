<!doctype html>
<html lang="en-US">
<head>
<meta name="google-site-verification" content="R5RRjtgb1OFBHTsgUvaNtPJ10MuodbzWHUiUz3uAN0Q" />
<meta name="google-site-verification" content="sixAci5VS7cvOdqcOafysSsUGwKzTAOpwB1uoYsHa0M" />
<meta name="verify-v1" content="vC35EcQpMwUv1wphX5oHoXjd92E1uZhIutp9eXO9uMk=" />
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v19.0 - https://yoast.com/wordpress/plugins/seo/ -->
	<link media="all" href="https://www.dangilroy.com/wp-content/cache/autoptimize/css/autoptimize_0e1b5559e852493a7712ddab072ae0c7.css" rel="stylesheet" /><link media="print" href="https://www.dangilroy.com/wp-content/cache/autoptimize/css/autoptimize_1947507dbe058c274f5b1689dcf2b34a.css" rel="stylesheet" /><title>Page not found | Dan Gilroy Design</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found | Dan Gilroy Design" />
	<meta property="og:site_name" content="Dan Gilroy Design" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://www.dangilroy.com/#organization","name":"Dan Gilroy Design","url":"https://www.dangilroy.com/","sameAs":["https://www.linkedin.com/company/9803785/admin/","https://www.facebook.com/DanGilroyDesign/","https://twitter.com/dangilroydesign"],"logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://www.dangilroy.com/#/schema/logo/image/","url":"https://www.dangilroy.com/wp-content/uploads/2022/03/Dan-Gilroy-Design-2022.png","contentUrl":"https://www.dangilroy.com/wp-content/uploads/2022/03/Dan-Gilroy-Design-2022.png","width":1600,"height":277,"caption":"Dan Gilroy Design"},"image":{"@id":"https://www.dangilroy.com/#/schema/logo/image/"}},{"@type":"WebSite","@id":"https://www.dangilroy.com/#website","url":"https://www.dangilroy.com/","name":"Dan Gilroy Design","description":"Law Firm Website Design","publisher":{"@id":"https://www.dangilroy.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.dangilroy.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="Dan Gilroy Design &raquo; Feed" href="https://www.dangilroy.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dan Gilroy Design &raquo; Comments Feed" href="https://www.dangilroy.com/comments/feed/" />

	









<script type='text/javascript' src='https://www.dangilroy.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>



<link rel="https://api.w.org/" href="https://www.dangilroy.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.dangilroy.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.dangilroy.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.9.3" />
<script type="text/javascript">document.documentElement.className += " js";</script>
<link rel="icon" href="https://www.dangilroy.com/wp-content/uploads/2022/04/cropped-favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.dangilroy.com/wp-content/uploads/2022/04/cropped-favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.dangilroy.com/wp-content/uploads/2022/04/cropped-favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.dangilroy.com/wp-content/uploads/2022/04/cropped-favicon-270x270.png" />
		
		<noscript><style id="rocket-lazyload-nojs-css">.rll-youtube-player, [data-lazy-src]{display:none !important;}</style></noscript>
<link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<script src="https://kit.fontawesome.com/6e1d190ad0.js" crossorigin="anonymous"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Alegreya+Sans:wght@300;400&family=Overpass:wght@300;400&family=Roboto&display=swap" rel="stylesheet">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-196787-4', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body class="error404 wp-custom-logo" id="page-top">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0.49803921568627" /><feFuncG type="table" tableValues="0 0.49803921568627" /><feFuncB type="table" tableValues="0 0.49803921568627" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 0.27843137254902" /><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0" /><feFuncG type="table" tableValues="0 0.64705882352941" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.78039215686275 1" /><feFuncG type="table" tableValues="0 0.94901960784314" /><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.44705882352941 0.4" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.098039215686275 1" /><feFuncG type="table" tableValues="0 0.66274509803922" /><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg>
<!-- STICKY HEADER
================================================== -->
<div class="header">
	
<section id="top-row" class="top-row-wrapper desktop-only hide">
<div class="top-row">
<div class="top-bar">
<small class="desktop-only">&nbsp;</small>
<div class="right-info"><a href="/request-a-quote/" class="quote-top-row hvr-sweep-to-right"><div class="desktop-only" style="margin-right:0"><i class="fa-regular fa-circle-chevron-right"></i>  Request A Quote</div></a>
<div class="phone-number-top-row desktop-only" style="margin-right:0">Call 503.754.8167</div>
</div>
</div>	
</div>
</section>		


<!-- NAVIGATION
================================================== -->

	
	<nav id="navigation" class="navigation">
<div class="nav-header">
<a href="https://www.dangilroy.com/" class="nav-logo" title="Dan Gilroy Design | Law Firm Website Design"><img src="https://www.dangilroy.com/wp-content/themes/dgd2021/images/2021/logo/Dan-Gilroy-Design-2022-4.png" alt="Dan Gilroy Design | Websites For Lawyers"></a>
<div class="nav-toggle"></div>
</div>
<div class="nav-menus-wrapper hide">
<ul id="menu-primary-menu" class="nav-menu align-to-right"><li id="menu-item-540" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-540"><a href="https://www.dangilroy.com/">Home</a></li>
<li id="menu-item-15" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-15"><a href="https://www.dangilroy.com/law-firm-website-design/">Our Work</a>
<ul class="nav-dropdown nav-submenu">
	<li id="menu-item-524" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-524"><a href="https://www.dangilroy.com/law-firm-website-design/">Law Firm Website Design</a></li>
	<li id="menu-item-491" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-491"><a href="https://www.dangilroy.com/law-firm-logo-design/">Law Firm Logo Design</a></li>
</ul>
</li>
<li id="menu-item-853" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-853"><a href="https://www.dangilroy.com/lawyer-website-design/">Website Design</a>
<ul class="nav-dropdown nav-submenu">
	<li id="menu-item-523" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-523"><a href="https://www.dangilroy.com/small-law-firm-website-design/">Small Law Firm Website Design</a></li>
	<li id="menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-39"><a href="https://www.dangilroy.com/mid-sized-law-firm-website-design/">Medium to Large-Sized Law Firms</a></li>
	<li id="menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-38"><a href="https://www.dangilroy.com/website-design-for-mediators/">Mediation Website Design</a></li>
	<li id="menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-37"><a href="https://www.dangilroy.com/law-firm-landing-page-design/">Law Firm Landing Page Design</a></li>
</ul>
</li>
<li id="menu-item-203" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-203"><a href="https://www.dangilroy.com/lawyer-seo/">SEO</a></li>
<li id="menu-item-538" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-538"><a href="https://www.dangilroy.com/law-firm-website-designer/">About</a></li>
<li id="menu-item-543" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-543"><a href="https://www.dangilroy.com/attorney-website-design-reviews/">Reviews</a></li>
<li id="menu-item-215" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-215"><a href="https://www.dangilroy.com/blog/">Blog</a></li>
<li id="menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-34"><a href="https://www.dangilroy.com/contact/">Contact</a></li>
</ul>
	

</nav>

</div><!--end sticky header-->

<!-- HEADER
================================================== -->

<div class="border-top border-bottom main-content margin-below-sticky-header stripe-bg">
	<div class="flex-container page-header">
			<div class="flex-50">
			<div class="heading-container-left "></div>
			</div>
			<div class="flex-50 breadcrumbs">
			
			</div>
		</div>
</div>

<!-- MAIN CONTENT
================================================== -->

<div class="white-band main-content no-hero">
<div class="container">
<div class="twelve columns"  style="text-align:center">

<h1 style="text-align:center">Sorry.  Page Not Found</h1>

<div class="intro-text"><p>The page you were looking for could not be found. It might have been removed, renamed, or did not exist in the first place.</p></div>

<form role="search" method="get" id="searchform" class="searchform" action="https://www.dangilroy.com/">
				<div>
					<label class="screen-reader-text" for="s">Search for:</label>
					<input type="text" value="" name="s" id="s" />
					<input type="submit" id="searchsubmit" value="Search" />
				</div>
			</form>
</div>

</div><!-- .section-inner -->

</div><!-- #site-content -->



<!-- PAGE BOTTOM
================================================== -->
	
<div class="band bottom">	
<footer class="container">
	
<div class="row">
			
		<div class="four columns">
		<h3>Navigate </h3>
		<ul>
						<li><a href="https://www.dangilroy.com/law-firm-website-design/">Law Firm Websites</a></li>
				<li><a href="https://www.dangilroy.com/lawyer-seo/">Lawyer SEO</a></li>
				<li><a href="https://www.dangilroy.com/attorney-website-design-reviews/">Client Reviews</a></li>
				<li><a href="https://www.dangilroy.com/law-firm-website-designer/">About Us</a></li>
				<li><a href="https://www.dangilroy.com/contact/">Contact Us</a></li>
						</ul>
		</div>
		
		<div class="four columns">		
		<h3>Explore</h3>
		<ul>
						<li><a href="https://www.dangilroy.com/small-law-firm-website-design/">Small Law Firm Website Design</a></li>
				<li><a href="https://www.dangilroy.com/small-law-firm-website-design/">Solo Attorney Website Design</a></li>
				<li><a href="https://www.dangilroy.com/mid-sized-law-firm-website-design/">Mid-Sized Law Firm Website Design</a></li>
				<li><a href="https://www.dangilroy.com/website-design-for-mediators/">Mediation Website Design</a></li>
				<li><a href="https://www.dangilroy.com/law-firm-landing-page-design/">Law Firm Landing Pages & Microsites</a></li>
				<li><a href="https://www.dangilroy.com/law-firm-logo-design/">Law Firm Logo Design</a></li>
						</ul>
		</div>
						
		<div class="four columns">		
		<h3>What's New</h3>
				<div  id="bottom-list">
				 
									
				<ul>
				<li><a href="https://www.dangilroy.com/san-francisco-mediation-website-launched-for-the-hon-paul-l-beeman-ret/">San Francisco mediation website design launched for The Hon. Paul L. Beeman (Ret.).</a></li>
				</ul>
					
				<ul>
				<li><a href="https://www.dangilroy.com/five-tips-to-better-law-firm-web-design/">Five practical tips to better law firm web design</a></li>
				</ul>
												</div>
		</div>

</div>





<div class="row">
		<div class="three columns footer-column">
		<div><img src="https://www.dangilroy.com/wp-content/themes/dgd2021/images/logo/footer/dan-gilroy-design.png" style="max-width:auto; height:auto; margin:0 0 0 0" alt="Logo: Dan Gilroy Design, LLC | Websites For Lawyers"></div>
		</div>
		
		<div class="six columns footer-column">
		<div class="sitemap-privacy-footer-links">	
		<p style="text-align: center; margin:0">Copyright &copy; 2022  <a href="https://www.dangilroy.com/">Dan Gilroy Design<br /><a href="/privacy-policy/">Privacy Policy</a>  |  <a href="/sitemap/">Sitemap</a></p>
		</div>
		</div>
		
		<div class="three columns footer-column">
			<div class="social-media-icons">
		<p><a href="https://twitter.com/dangilroydesign/" target="_blank"><i class="fa fa-twitter-square fa-2x" aria-hidden="true"></i></a>  <a href="https://www.facebook.com/DanGilroyDesign/" target="_blank"><i class="fa fa-facebook-square  fa-2x" aria-hidden="true"></i></a>  <a href="https://www.linkedin.com/company/dan-gilroy-design/" target="_blank"><i class="fa fa-linkedin-square  fa-2x" aria-hidden="true"></i></a></p>
			</div>
		</div>
</div>

	
</footer><!-- container -->
</div><!--end band-->


<!-- CALL NOW - MOBILE ONLY
================================================== -->

<div class="band" id="callnowbutton">
<p><i class="fa fa-phone-square" aria-hidden="true"></i>  <a href="tel:5037548167">Call</a>  <i class="fa fa-envelope"  aria-hidden="true"></i>  <a href="/request-a-quote/">Get A Quote</a></p> 
</div>

<script>
              (function(e){
                  var el = document.createElement('script');
                  el.setAttribute('data-account', 'c94FMlEzVC');
                  el.setAttribute('src', 'https://cdn.userway.org/widget.js');
                  document.body.appendChild(el);
                })();
              </script><script type='text/javascript' id='eeb-js-ajax-ef-js-extra'>
/* <![CDATA[ */
var eeb_ef = {"ajaxurl":"https:\/\/www.dangilroy.com\/wp-admin\/admin-ajax.php","security":"f2b28e1632"};
/* ]]> */
</script>

<script type='text/javascript' id='rocket-browser-checker-js-after'>
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
</script>
<script type='text/javascript' id='rocket-preload-links-js-extra'>
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/(index\\.php\/)?wp\\-json(\/.*|$)|\/wp-admin\/|\/logout\/|\/wp-login.php|\/refer\/|\/go\/|\/recommend\/|\/recommends\/","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https:\/\/www.dangilroy.com","onHoverDelay":"100","rateThrottle":"3"};
/* ]]> */
</script>
<script type='text/javascript' id='rocket-preload-links-js-after'>
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
</script>




<script>window.lazyLoadOptions={elements_selector:"img[data-lazy-src],.rocket-lazyload",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,callback_loaded:function(element){if(element.tagName==="IFRAME"&&element.dataset.rocketLazyload=="fitvidscompatible"){if(element.classList.contains("lazyloaded")){if(typeof window.jQuery!="undefined"){if(jQuery.fn.fitVids){jQuery(element).parent().fitVids()}}}}}};window.addEventListener('LazyLoad::Initialized',function(e){var lazyLoadInstance=e.detail.instance;if(window.MutationObserver){var observer=new MutationObserver(function(mutations){var image_count=0;var iframe_count=0;var rocketlazy_count=0;mutations.forEach(function(mutation){for(var i=0;i<mutation.addedNodes.length;i++){if(typeof mutation.addedNodes[i].getElementsByTagName!=='function'){continue}
if(typeof mutation.addedNodes[i].getElementsByClassName!=='function'){continue}
images=mutation.addedNodes[i].getElementsByTagName('img');is_image=mutation.addedNodes[i].tagName=="IMG";iframes=mutation.addedNodes[i].getElementsByTagName('iframe');is_iframe=mutation.addedNodes[i].tagName=="IFRAME";rocket_lazy=mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');image_count+=images.length;iframe_count+=iframes.length;rocketlazy_count+=rocket_lazy.length;if(is_image){image_count+=1}
if(is_iframe){iframe_count+=1}}});if(image_count>0||iframe_count>0||rocketlazy_count>0){lazyLoadInstance.update()}});var b=document.getElementsByTagName("body")[0];var config={childList:!0,subtree:!0};observer.observe(b,config)}},!1)</script>		
<script type="text/javascript">
var sc_project=4117319; 
var sc_invisible=1; 
var sc_security="d6f2e2e0"; 
var sc_remove_link=1; 
</script>
<script type="text/javascript"
src="https://www.statcounter.com/counter/counter.js"
async></script>
<noscript><div class="statcounter"><img class="statcounter"
src="https://c.statcounter.com/4117319/0/d6f2e2e0/1/"
alt="Web Analytics"></div></noscript>
<script defer src="https://www.dangilroy.com/wp-content/cache/autoptimize/js/autoptimize_03c1c4630bc08f6ba020167c9997fbeb.js"></script></body>
</html>
